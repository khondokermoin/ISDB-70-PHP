<?php
session_start();
require_once '../includes/auth.php';
require_admin_login();
require_once '../config/db.php';

// শুধুমাত্র POST রিকোয়েস্ট — GET দিয়ে আর মুছে ফেলা যাবে না
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: dashboard.php");
    exit;
}

verify_csrf_token($_POST['csrf_token'] ?? '');

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
if (!$id) {
    set_flash('error', 'অবৈধ অনুরোধ।');
    header("Location: dashboard.php");
    exit;
}

try {
    // ঘড়ির ছবিগুলো খুঁজে বের করে ফোল্ডার থেকে মুছে ফেলা
    $stmt = $pdo->prepare("SELECT image_url FROM watch_images WHERE watch_id = :id");
    $stmt->execute([':id' => $id]);
    $images = $stmt->fetchAll();

    foreach ($images as $img) {
        $path = __DIR__ . '/../' . $img['image_url'];
        if (file_exists($path)) {
            unlink($path);
        }
    }

    // ডাটাবেজ থেকে মুছে ফেলা (ON DELETE CASCADE থাকলে watch_images স্বয়ংক্রিয় মুছবে)
    $del = $pdo->prepare("DELETE FROM watches WHERE id = :id");
    $del->execute([':id' => $id]);

    set_flash('success', 'ঘড়িটি সফলভাবে মুছে ফেলা হয়েছে।');
} catch (PDOException $e) {
    error_log("delete_watch error: " . $e->getMessage());
    set_flash('error', 'মুছতে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
}

header("Location: dashboard.php");
exit;
