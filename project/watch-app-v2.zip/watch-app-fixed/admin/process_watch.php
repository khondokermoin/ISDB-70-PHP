<?php
session_start();
require_once '../includes/auth.php';
require_admin_login();           // Auth চেক — আগে ছিল না, এখন আছে
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: add_watch.php");
    exit;
}

// CSRF যাচাই
verify_csrf_token($_POST['csrf_token'] ?? '');

$action = $_POST['action'] ?? 'add';  // 'add' অথবা 'edit'
$id     = isset($_POST['id']) ? (int)$_POST['id'] : 0;

// ইনপুট স্যানিটাইজ
$name          = trim($_POST['name']          ?? '');
$model         = trim($_POST['model']         ?? '');
$brand         = trim($_POST['brand']         ?? '');
$buying_price  = (float)($_POST['buying_price']  ?? 0);
$selling_price = (float)($_POST['selling_price'] ?? 0);
$description   = trim($_POST['description']   ?? '');
$quantity      = max(0, (int)($_POST['quantity'] ?? 0));

// বেসিক ভ্যালিডেশন
if (empty($name) || empty($model) || $buying_price <= 0 || $selling_price <= 0) {
    set_flash('error', 'নাম, মডেল এবং দাম পূরণ করতে হবে।');
    header("Location: " . ($action === 'edit' ? "edit_watch.php?id=$id" : "add_watch.php"));
    exit;
}

try {
    $pdo->beginTransaction();

    if ($action === 'add') {
        $stmt = $pdo->prepare("
            INSERT INTO watches (name, model, brand, buying_price, selling_price, description, quantity, created_at)
            VALUES (:name, :model, :brand, :buying, :selling, :desc, :qty, NOW())
        ");
        $stmt->execute([
            ':name'   => $name,
            ':model'  => $model,
            ':brand'  => $brand,
            ':buying' => $buying_price,
            ':selling'=> $selling_price,
            ':desc'   => $description,
            ':qty'    => $quantity,
        ]);
        $watch_id = (int)$pdo->lastInsertId();

    } else {
        // Edit — ID যাচাই করা
        $check = $pdo->prepare("SELECT id FROM watches WHERE id = :id");
        $check->execute([':id' => $id]);
        if (!$check->fetch()) {
            set_flash('error', 'ঘড়িটি পাওয়া যায়নি।');
            header("Location: dashboard.php");
            exit;
        }
        $stmt = $pdo->prepare("
            UPDATE watches SET
                name = :name, model = :model, brand = :brand,
                buying_price = :buying, selling_price = :selling,
                description = :desc, quantity = :qty
            WHERE id = :id
        ");
        $stmt->execute([
            ':name'   => $name,
            ':model'  => $model,
            ':brand'  => $brand,
            ':buying' => $buying_price,
            ':selling'=> $selling_price,
            ':desc'   => $description,
            ':qty'    => $quantity,
            ':id'     => $id,
        ]);
        $watch_id = $id;
    }

    // ছবি আপলোড (রিইউজেবল ফাংশন)
    $filesKey = ($action === 'add') ? 'images' : 'new_images';
    if (!empty($_FILES[$filesKey]['name'][0])) {
        $result = upload_images($_FILES[$filesKey], $pdo, $watch_id);
        if (!empty($result['errors'])) {
            // কিছু ছবি আপলোড হয়েছে, কিছু হয়নি — commit করি, error জানাই
            $pdo->commit();
            set_flash('error', implode(' | ', $result['errors']));
            header("Location: edit_watch.php?id=$watch_id");
            exit;
        }
    }

    $pdo->commit();

    $msg = ($action === 'add') ? 'নতুন ঘড়ি সফলভাবে যোগ হয়েছে!' : 'ঘড়ির তথ্য আপডেট হয়েছে!';
    set_flash('success', $msg);
    header("Location: " . ($action === 'add' ? "add_watch.php" : "dashboard.php"));
    exit;

} catch (Exception $e) {
    $pdo->rollBack();
    error_log("process_watch error: " . $e->getMessage());
    set_flash('error', 'একটি সার্ভার সমস্যা হয়েছে। পরে আবার চেষ্টা করুন।');
    header("Location: " . ($action === 'edit' ? "edit_watch.php?id=$id" : "add_watch.php"));
    exit;
}
