<?php
session_start();
require_once '../includes/auth.php';
require_admin_login();
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>নতুন ঘড়ি যোগ করুন — Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans p-6">

<div class="max-w-3xl mx-auto bg-white p-8 rounded-xl shadow-md mt-6">
    <div class="flex justify-between items-center mb-6 border-b pb-4">
        <div>
            <h2 class="text-xl font-bold text-gray-800">নতুন ঘড়ি যোগ করুন</h2>
            <p class="text-xs text-gray-400 mt-0.5">সব তারকা (*) চিহ্নিত ফিল্ড পূরণ করতে হবে</p>
        </div>
        <a href="dashboard.php" class="text-sm text-blue-600 hover:underline">← Dashboard</a>
    </div>

    <?php if (!empty($flash)): ?>
        <?php $bg = $flash['type'] === 'success' ? 'bg-green-50 border-green-400 text-green-800' : 'bg-red-50 border-red-400 text-red-800'; ?>
        <div class="<?= $bg ?> border-l-4 px-4 py-3 rounded mb-5 text-sm">
            <?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <form action="process_watch.php" method="POST" enctype="multipart/form-data" class="space-y-5">
        <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
        <input type="hidden" name="action" value="add">

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">ঘড়ির নাম *</label>
                <input type="text" name="name" required maxlength="150"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="e.g. Casio G-Shock">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">মডেল নম্বর *</label>
                <input type="text" name="model" required maxlength="100"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="e.g. GA-110">
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">ব্র্যান্ড</label>
                <input type="text" name="brand" maxlength="80"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="e.g. Casio">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">কেনার দাম (৳) *</label>
                <input type="number" step="0.01" min="0" name="buying_price" required
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="5000">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">বিক্রির দাম (৳) *</label>
                <input type="number" step="0.01" min="0" name="selling_price" required
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="6500">
            </div>
        </div>

        <div>
            <label class="block text-sm font-semibold text-gray-700 mb-1">স্টক পরিমাণ *</label>
            <input type="number" name="quantity" min="0" value="1" required
                class="w-40 px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none">
            <p class="text-xs text-gray-400 mt-1">কতটি পিস হাতে আছে</p>
        </div>

        <div>
            <label class="block text-sm font-semibold text-gray-700 mb-1">বিবরণ (ডেসক্রিপশন)</label>
            <textarea name="description" rows="9"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none font-mono text-sm"
                placeholder="Product Type: Men's Sport Watch&#10;Case Material: Resin&#10;Dial Diameter: 50mm&#10;Water Resistant: 200m&#10;..."></textarea>
            <p class="text-xs text-gray-400 mt-1">প্রতিটি লাইন আলাদা পয়েন্ট হিসেবে কপি হবে</p>
        </div>

        <div>
            <label class="block text-sm font-semibold text-gray-700 mb-1">ঘড়ির ছবি (একাধিক)</label>
            <input type="file" name="images[]" multiple accept="image/jpeg,image/png,image/webp,image/gif"
                class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
            <p class="text-xs text-gray-400 mt-1">শুধু JPG, PNG, WEBP, GIF — প্রতিটি সর্বোচ্চ 5MB।  Ctrl/Cmd চেপে একাধিক ছবি বেছে নিন।</p>
        </div>

        <div class="pt-2">
            <button type="submit"
                class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition">
                💾 সেভ করুন
            </button>
        </div>
    </form>
</div>

</body>
</html>
