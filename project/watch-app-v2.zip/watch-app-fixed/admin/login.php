<?php
session_start();
require_once '../includes/auth.php';

if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: dashboard.php");
    exit;
}

require_once '../config/db.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!empty($username) && !empty($password)) {
        $stmt = $pdo->prepare("SELECT id, username, password FROM admins WHERE username = :username LIMIT 1");
        $stmt->execute([':username' => $username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            session_regenerate_id(true); // Session fixation প্রতিরোধ
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username']  = $admin['username'];
            $_SESSION['admin_id']        = $admin['id'];
            header("Location: dashboard.php");
            exit;
        } else {
            // ইউজারনেম বা পাসওয়ার্ড — কোনটা ভুল সেটা বলা হচ্ছে না (security best practice)
            $error = "ইউজারনেম অথবা পাসওয়ার্ড সঠিক নয়।";
        }
    } else {
        $error = "ইউজারনেম এবং পাসওয়ার্ড পূরণ করতে হবে।";
    }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login — Watch Inventory</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center font-sans">

    <div class="bg-white p-8 rounded-xl shadow-lg w-full max-w-md">
        <div class="text-center mb-6">
            <span class="text-4xl">⌚</span>
            <h2 class="text-2xl font-bold text-gray-800 mt-2">Admin Login</h2>
            <p class="text-sm text-gray-500">Watch Inventory Management</p>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 mb-5 rounded" role="alert">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" class="space-y-5">
            <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
            <div>
                <label class="block text-gray-700 text-sm font-semibold mb-1">Username</label>
                <input type="text" name="username" required autocomplete="username"
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value="<?= htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
            </div>
            <div>
                <label class="block text-gray-700 text-sm font-semibold mb-1">Password</label>
                <input type="password" name="password" required autocomplete="current-password"
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <button type="submit"
                class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-4 rounded-lg transition duration-200">
                লগইন করুন
            </button>
        </form>

        <p class="text-center text-xs text-gray-400 mt-5">
            <a href="../index.php" class="hover:underline">← মেইন সাইটে ফিরুন</a>
        </p>
    </div>

</body>
</html>
