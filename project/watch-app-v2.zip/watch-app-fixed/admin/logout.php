<?php
session_start();
session_unset();
session_destroy();

// নতুন সেশন শুরু করে flash দেওয়া
session_start();
set_flash('success', 'সফলভাবে লগআউট হয়েছে।');

header("Location: login.php");
exit;
