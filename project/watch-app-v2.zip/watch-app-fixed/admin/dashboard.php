<?php
session_start();
require_once '../includes/auth.php';
require_admin_login();
require_once '../config/db.php';

$flash = get_flash();

// সব ঘড়ির তথ্য — একটি কোয়েরিতে ছবিও
$stmt = $pdo->query("
    SELECT w.*,
           (SELECT image_url FROM watch_images WHERE watch_id = w.id ORDER BY sort_order ASC LIMIT 1) AS thumb
    FROM watches w
    ORDER BY w.id DESC
");
$watches = $stmt->fetchAll();

// সারসংক্ষেপ তথ্য
$summary = $pdo->query("
    SELECT
        COUNT(*) AS total_watches,
        SUM(buying_price * COALESCE(quantity,0))  AS total_buying_value,
        SUM(selling_price * COALESCE(quantity,0)) AS total_selling_value,
        SUM((selling_price - buying_price) * COALESCE(quantity,0)) AS total_profit,
        SUM(quantity) AS total_stock
    FROM watches
")->fetch();
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — Watch Inventory</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen font-sans">

<!-- Navbar -->
<nav class="bg-white shadow-sm py-3 px-6 flex justify-between items-center sticky top-0 z-10">
    <div class="flex items-center gap-2">
        <span class="text-xl">⌚</span>
        <span class="font-bold text-gray-700">Watch Inventory — Admin</span>
    </div>
    <div class="flex gap-2">
        <a href="../index.php" class="text-sm bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg transition">🌐 সাইট দেখুন</a>
        <a href="add_watch.php" class="text-sm bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-lg transition">+ নতুন ঘড়ি</a>
        <a href="logout.php" class="text-sm bg-red-500 hover:bg-red-600 text-white px-3 py-1.5 rounded-lg transition">Logout</a>
    </div>
</nav>

<div class="max-w-7xl mx-auto px-4 py-6">

    <!-- Flash message -->
    <?php if (!empty($flash)): ?>
        <?php $bg = $flash['type'] === 'success' ? 'bg-green-50 border-green-400 text-green-800' : 'bg-red-50 border-red-400 text-red-800'; ?>
        <div class="<?= $bg ?> border-l-4 px-4 py-3 rounded mb-5">
            <?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <!-- Summary Cards -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
            <p class="text-xs text-gray-500 mb-1">মোট ঘড়ি</p>
            <p class="text-2xl font-bold text-gray-800"><?= (int)$summary['total_watches'] ?></p>
        </div>
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
            <p class="text-xs text-gray-500 mb-1">মোট স্টক</p>
            <p class="text-2xl font-bold text-blue-600"><?= (int)$summary['total_stock'] ?></p>
        </div>
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
            <p class="text-xs text-gray-500 mb-1">মোট বিনিয়োগ</p>
            <p class="text-2xl font-bold text-red-500">৳<?= number_format((float)$summary['total_buying_value']) ?></p>
        </div>
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
            <p class="text-xs text-gray-500 mb-1">সম্ভাব্য মুনাফা</p>
            <p class="text-2xl font-bold text-green-600">৳<?= number_format((float)$summary['total_profit']) ?></p>
        </div>
    </div>

    <!-- Watch Table -->
    <div class="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100">
        <div class="px-5 py-4 border-b border-gray-100 flex justify-between items-center">
            <h2 class="font-semibold text-gray-700">ঘড়ির তালিকা (<?= count($watches) ?> টি)</h2>
            <input type="text" id="tableSearch" oninput="filterTable()" placeholder="সার্চ করুন..."
                class="text-sm border border-gray-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-400">
        </div>
        <div class="overflow-x-auto">
        <table class="w-full text-left text-sm" id="watchTable">
            <thead class="bg-gray-50 text-gray-600 uppercase text-xs">
                <tr>
                    <th class="px-4 py-3">ছবি</th>
                    <th class="px-4 py-3">নাম / মডেল</th>
                    <th class="px-4 py-3">ব্র্যান্ড</th>
                    <th class="px-4 py-3">কেনা দাম</th>
                    <th class="px-4 py-3">বিক্রি দাম</th>
                    <th class="px-4 py-3">মুনাফা</th>
                    <th class="px-4 py-3">স্টক</th>
                    <th class="px-4 py-3 text-center">অ্যাকশন</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($watches as $w):
                    $profit = $w['selling_price'] - $w['buying_price'];
                    $qty    = (int)($w['quantity'] ?? 0);
                    if ($qty <= 0) { $stockClass = 'badge-outstock'; $stockLabel = 'আউট অফ স্টক'; }
                    elseif ($qty <= 3) { $stockClass = 'badge-lowstock'; $stockLabel = 'কম ('.$qty.')'; }
                    else { $stockClass = 'badge-instock'; $stockLabel = 'আছে ('.$qty.')'; }
                ?>
                <tr class="hover:bg-gray-50 watch-row">
                    <td class="px-4 py-3">
                        <?php if ($w['thumb']): ?>
                            <img src="../<?= htmlspecialchars($w['thumb'], ENT_QUOTES, 'UTF-8') ?>"
                                 class="w-12 h-12 object-cover rounded-lg border" alt="">
                        <?php else: ?>
                            <div class="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center text-gray-300">📷</div>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3">
                        <p class="font-semibold text-gray-800 row-name"><?= htmlspecialchars($w['name'], ENT_QUOTES, 'UTF-8') ?></p>
                        <p class="text-gray-400 text-xs row-model"><?= htmlspecialchars($w['model'], ENT_QUOTES, 'UTF-8') ?></p>
                    </td>
                    <td class="px-4 py-3 text-gray-600 row-brand"><?= htmlspecialchars($w['brand'] ?? '—', ENT_QUOTES, 'UTF-8') ?></td>
                    <td class="px-4 py-3 text-red-500">৳<?= number_format((float)$w['buying_price']) ?></td>
                    <td class="px-4 py-3 text-green-600 font-semibold">৳<?= number_format((float)$w['selling_price']) ?></td>
                    <td class="px-4 py-3 text-blue-600 font-semibold">৳<?= number_format($profit) ?></td>
                    <td class="px-4 py-3">
                        <span class="<?= $stockClass ?> text-xs font-semibold px-2 py-1 rounded-full"><?= $stockLabel ?></span>
                    </td>
                    <td class="px-4 py-3 text-center">
                        <div class="flex justify-center gap-2">
                            <a href="edit_watch.php?id=<?= (int)$w['id'] ?>"
                               class="bg-yellow-400 hover:bg-yellow-500 text-white text-xs px-3 py-1.5 rounded-lg transition">✏️ Edit</a>
                            <!-- DELETE: POST ফর্ম — GET link নয় -->
                            <form action="delete_watch.php" method="POST"
                                  onsubmit="return confirm('নিশ্চিত? এই ঘড়ি ও সব ছবি মুছে যাবে।')">
                                <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
                                <input type="hidden" name="id" value="<?= (int)$w['id'] ?>">
                                <button type="submit"
                                    class="bg-red-500 hover:bg-red-600 text-white text-xs px-3 py-1.5 rounded-lg transition">🗑 Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>

                <?php if (empty($watches)): ?>
                <tr><td colspan="8" class="text-center py-10 text-gray-400">কোনো ঘড়ি যোগ করা হয়নি।</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<script>
function filterTable() {
    const q = document.getElementById('tableSearch').value.toLowerCase();
    document.querySelectorAll('.watch-row').forEach(row => {
        const name  = row.querySelector('.row-name')?.innerText.toLowerCase()  || '';
        const model = row.querySelector('.row-model')?.innerText.toLowerCase() || '';
        const brand = row.querySelector('.row-brand')?.innerText.toLowerCase() || '';
        row.style.display = (name+model+brand).includes(q) ? '' : 'none';
    });
}
</script>
<link rel="stylesheet" href="../assets/css/style.css">
</body>
</html>
