<?php
session_start();
require_once '../includes/auth.php';
require_admin_login();
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: dashboard.php");
    exit;
}

verify_csrf_token($_POST['csrf_token'] ?? '');

$img_id  = isset($_POST['img_id'])  ? (int)$_POST['img_id']  : 0;
$watch_id= isset($_POST['watch_id'])? (int)$_POST['watch_id']: 0;

if ($img_id && $watch_id) {
    try {
        // নিশ্চিত করা যে ছবিটি এই ঘড়ির
        $stmt = $pdo->prepare("SELECT image_url FROM watch_images WHERE id = :id AND watch_id = :wid");
        $stmt->execute([':id' => $img_id, ':wid' => $watch_id]);
        $image = $stmt->fetch();

        if ($image) {
            $path = __DIR__ . '/../' . $image['image_url'];
            if (file_exists($path)) unlink($path);

            $del = $pdo->prepare("DELETE FROM watch_images WHERE id = :id");
            $del->execute([':id' => $img_id]);
            set_flash('success', 'ছবিটি মুছে ফেলা হয়েছে।');
        } else {
            set_flash('error', 'ছবি পাওয়া যায়নি।');
        }
    } catch (PDOException $e) {
        error_log("delete_image error: " . $e->getMessage());
        set_flash('error', 'মুছতে সমস্যা হয়েছে।');
    }
}

header("Location: edit_watch.php?id=" . $watch_id);
exit;
