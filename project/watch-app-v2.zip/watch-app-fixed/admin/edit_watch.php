<?php
session_start();
require_once '../includes/auth.php';
require_admin_login();
require_once '../config/db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) { header("Location: dashboard.php"); exit; }

$stmt = $pdo->prepare("SELECT * FROM watches WHERE id = :id");
$stmt->execute([':id' => $id]);
$watch = $stmt->fetch();
if (!$watch) { set_flash('error', 'ঘড়িটি পাওয়া যায়নি।'); header("Location: dashboard.php"); exit; }

$imgStmt = $pdo->prepare("SELECT * FROM watch_images WHERE watch_id = :id ORDER BY sort_order ASC");
$imgStmt->execute([':id' => $id]);
$images = $imgStmt->fetchAll();

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ঘড়ি সম্পাদনা — Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans p-6">

<div class="max-w-3xl mx-auto bg-white p-8 rounded-xl shadow-md mt-6">
    <div class="flex justify-between items-center mb-6 border-b pb-4">
        <div>
            <h2 class="text-xl font-bold text-gray-800">ঘড়ির তথ্য আপডেট করুন</h2>
            <p class="text-xs text-gray-400 mt-0.5">ID: <?= $id ?> — <?= htmlspecialchars($watch['name'], ENT_QUOTES, 'UTF-8') ?></p>
        </div>
        <a href="dashboard.php" class="text-sm text-blue-600 hover:underline">← Dashboard</a>
    </div>

    <?php if (!empty($flash)): ?>
        <?php $bg = $flash['type'] === 'success' ? 'bg-green-50 border-green-400 text-green-800' : 'bg-red-50 border-red-400 text-red-800'; ?>
        <div class="<?= $bg ?> border-l-4 px-4 py-3 rounded mb-5 text-sm">
            <?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <form action="process_watch.php" method="POST" enctype="multipart/form-data" class="space-y-5">
        <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="id" value="<?= $id ?>">

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">ঘড়ির নাম *</label>
                <input type="text" name="name" required maxlength="150"
                    value="<?= htmlspecialchars($watch['name'], ENT_QUOTES, 'UTF-8') ?>"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">মডেল নম্বর *</label>
                <input type="text" name="model" required maxlength="100"
                    value="<?= htmlspecialchars($watch['model'], ENT_QUOTES, 'UTF-8') ?>"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none">
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">ব্র্যান্ড</label>
                <input type="text" name="brand" maxlength="80"
                    value="<?= htmlspecialchars($watch['brand'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">কেনার দাম (৳) *</label>
                <input type="number" step="0.01" min="0" name="buying_price" required
                    value="<?= $watch['buying_price'] ?>"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">বিক্রির দাম (৳) *</label>
                <input type="number" step="0.01" min="0" name="selling_price" required
                    value="<?= $watch['selling_price'] ?>"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none">
            </div>
        </div>

        <div>
            <label class="block text-sm font-semibold text-gray-700 mb-1">স্টক পরিমাণ *</label>
            <input type="number" name="quantity" min="0"
                value="<?= (int)($watch['quantity'] ?? 0) ?>" required
                class="w-40 px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none">
        </div>

        <div>
            <label class="block text-sm font-semibold text-gray-700 mb-1">বিবরণ</label>
            <textarea name="description" rows="9"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 outline-none font-mono text-sm"><?= htmlspecialchars($watch['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
        </div>

        <!-- বর্তমান ছবি -->
        <?php if (!empty($images)): ?>
        <div>
            <label class="block text-sm font-semibold text-gray-700 mb-2">বর্তমান ছবি (hover করলে Delete দেখাবে)</label>
            <div class="flex flex-wrap gap-3">
                <?php foreach ($images as $img): ?>
                    <div class="relative group">
                        <img src="../<?= htmlspecialchars($img['image_url'], ENT_QUOTES, 'UTF-8') ?>"
                             class="w-24 h-24 object-cover rounded-lg border border-gray-200" alt="">
                        <!-- DELETE IMAGE: POST ফর্ম -->
                        <form action="delete_image.php" method="POST"
                              onsubmit="return confirm('এই ছবিটি মুছে ফেলবেন?')"
                              class="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition">
                            <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
                            <input type="hidden" name="img_id"   value="<?= (int)$img['id'] ?>">
                            <input type="hidden" name="watch_id" value="<?= $id ?>">
                            <button type="submit"
                                class="bg-red-600 text-white w-6 h-6 rounded-full text-xs flex items-center justify-center leading-none">✕</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- নতুন ছবি যোগ -->
        <div>
            <label class="block text-sm font-semibold text-gray-700 mb-1">নতুন ছবি যোগ করুন (ঐচ্ছিক)</label>
            <input type="file" name="new_images[]" multiple accept="image/jpeg,image/png,image/webp,image/gif"
                class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
            <p class="text-xs text-gray-400 mt-1">শুধু JPG, PNG, WEBP, GIF — সর্বোচ্চ 5MB প্রতিটি</p>
        </div>

        <div class="pt-2 flex gap-3">
            <button type="submit"
                class="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition">
                ✅ আপডেট করুন
            </button>
            <a href="dashboard.php"
               class="flex-1 text-center bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-3 rounded-lg transition">
               বাতিল
            </a>
        </div>
    </form>
</div>

</body>
</html>
