<?php
/**
 * create_admin.php — প্রথমবার অ্যাডমিন তৈরির জন্য
 *
 * ব্যবহারের পর এই ফাইলটি DELETE করুন অথবা web-accessible ফোল্ডারের বাইরে রাখুন।
 * URL: admin/create_admin.php?token=CHANGE_THIS_TOKEN
 */

// ---- এখানে আপনার নিজস্ব টোকেন বসান ----
define('SETUP_TOKEN', 'CHANGE_THIS_TO_A_RANDOM_STRING_12345');
// -----------------------------------------

if (!isset($_GET['token']) || $_GET['token'] !== SETUP_TOKEN) {
    http_response_code(403);
    die("Access denied. Provide the correct setup token in the URL.");
}

require_once '../config/db.php';

// ---- নিচে ইউজারনেম ও পাসওয়ার্ড পরিবর্তন করুন ----
$new_username = 'admin';
$new_password = 'YourStrongPassword123!';
// ---------------------------------------------------

if (strlen($new_password) < 8) {
    die("Error: Password must be at least 8 characters.");
}

$hashed = password_hash($new_password, PASSWORD_DEFAULT);

try {
    // একই নামের ইউজার থাকলে আপডেট করা, না থাকলে নতুন তৈরি
    $check = $pdo->prepare("SELECT id FROM admins WHERE username = :u");
    $check->execute([':u' => $new_username]);
    $exists = $check->fetch();

    if ($exists) {
        $stmt = $pdo->prepare("UPDATE admins SET password = :p WHERE username = :u");
        $stmt->execute([':p' => $hashed, ':u' => $new_username]);
        echo "<p style='color:green'>✅ Admin password updated successfully.</p>";
    } else {
        $stmt = $pdo->prepare("INSERT INTO admins (username, password) VALUES (:u, :p)");
        $stmt->execute([':u' => $new_username, ':p' => $hashed]);
        echo "<p style='color:green'>✅ Admin created successfully.</p>";
    }

    echo "<p><strong>Username:</strong> " . htmlspecialchars($new_username) . "</p>";
    echo "<p><strong>Password:</strong> " . htmlspecialchars($new_password) . "</p>";
    echo "<p><a href='login.php'>→ Login Page</a></p>";
    echo "<p style='color:red'><strong>⚠️ সতর্কতা:</strong> এই ফাইলটি এখনই ডিলিট করুন বা অন্য জায়গায় সরিয়ে ফেলুন!</p>";

} catch (PDOException $e) {
    error_log($e->getMessage());
    die("A database error occurred.");
}
