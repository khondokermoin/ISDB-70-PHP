<?php
require_once 'config/db.php';

// একটি JOIN কোয়েরিতে সব ঘড়ি ও তাদের ছবি আনা — N+1 সমস্যা দূর
$watches = $pdo->query("
    SELECT * FROM watches ORDER BY id DESC
")->fetchAll();

// সব ঘড়ির ছবি একটিমাত্র কোয়েরিতে আনা
$allImages = $pdo->query("
    SELECT * FROM watch_images ORDER BY watch_id, sort_order ASC
")->fetchAll();

// ছবি watch_id অনুযায়ী গ্রুপ করা
$imageMap = [];
foreach ($allImages as $img) {
    $imageMap[$img['watch_id']][] = $img;
}

// ব্র্যান্ড তালিকা ফিল্টারের জন্য
$brands = $pdo->query("SELECT DISTINCT brand FROM watches WHERE brand IS NOT NULL AND brand != '' ORDER BY brand")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Watch Inventory — স্টাফ প্যানেল</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-gray-100 text-gray-800 font-sans">

<!-- Navbar -->
<nav class="bg-white shadow-sm py-4 sticky top-0 z-10">
    <div class="max-w-7xl mx-auto px-4 flex justify-between items-center">
        <div class="flex items-center gap-2">
            <span class="text-2xl">⌚</span>
            <h1 class="text-xl font-bold text-gray-700">Watch Inventory</h1>
        </div>
        <div class="flex items-center gap-3">
            <span class="text-sm font-semibold text-blue-600 bg-blue-50 px-3 py-1 rounded-full hidden sm:block">Staff Panel</span>
            <a href="admin/login.php"
               class="bg-gray-800 hover:bg-gray-900 text-white text-sm px-4 py-1.5 rounded-lg font-medium transition">
                Admin Login
            </a>
        </div>
    </div>
</nav>

<div class="max-w-7xl mx-auto px-4 pb-12 pt-6">

    <!-- সার্চ + ব্র্যান্ড ফিল্টার -->
    <div class="mb-8 flex flex-col md:flex-row gap-3 items-center">
        <div class="relative flex-1 w-full md:max-w-md">
            <input type="text" id="searchInput" oninput="filterWatches()" placeholder="ঘড়ির নাম, মডেল বা ব্র্যান্ড..."
                class="w-full px-5 py-3 pl-11 border border-gray-300 rounded-full shadow-sm focus:ring-2 focus:ring-blue-400 focus:border-blue-400 outline-none transition">
            <span class="absolute left-4 top-3.5 text-gray-400 text-base">🔎</span>
        </div>

        <?php if (!empty($brands)): ?>
        <div class="flex flex-wrap gap-2">
            <button onclick="filterByBrand('')"
                class="brand-btn active text-xs font-semibold px-3 py-1.5 rounded-full border border-gray-300 bg-gray-800 text-white transition">
                সব
            </button>
            <?php foreach ($brands as $brand): ?>
            <button onclick="filterByBrand('<?= htmlspecialchars($brand, ENT_QUOTES, 'UTF-8') ?>')"
                class="brand-btn text-xs font-semibold px-3 py-1.5 rounded-full border border-gray-300 bg-white text-gray-600 hover:bg-gray-100 transition">
                <?= htmlspecialchars($brand, ENT_QUOTES, 'UTF-8') ?>
            </button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- ঘড়ির কার্ড গ্রিড -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="watchesContainer">

        <?php foreach ($watches as $watch):
            $wid    = (int)$watch['id'];
            $imgs   = $imageMap[$wid] ?? [];
            $qty    = (int)($watch['quantity'] ?? 0);
            $urlArr = array_column($imgs, 'image_url');
            $urlStr = implode(',', $urlArr);

            if ($qty <= 0) { $stockClass = 'badge-outstock'; $stockLabel = 'স্টক নেই'; }
            elseif ($qty <= 3) { $stockClass = 'badge-lowstock'; $stockLabel = 'কম স্টক ('.$qty.')'; }
            else { $stockClass = 'badge-instock'; $stockLabel = 'স্টকে আছে ('.$qty.')'; }
        ?>
        <div class="watch-card bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow duration-200"
             data-brand="<?= htmlspecialchars(strtolower($watch['brand'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">

            <!-- ছবি স্লাইডার -->
            <div class="relative">
                <div id="slider-<?= $wid ?>" class="flex overflow-x-auto scrollbar-hide snap-x h-60 bg-gray-50">
                    <?php if (!empty($imgs)): ?>
                        <?php foreach ($imgs as $img): ?>
                        <div class="slide-item min-w-full snap-center">
                            <img src="<?= htmlspecialchars($img['image_url'], ENT_QUOTES, 'UTF-8') ?>"
                                 alt="<?= htmlspecialchars($watch['name'], ENT_QUOTES, 'UTF-8') ?>"
                                 class="w-full h-full object-cover" loading="lazy">
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="flex items-center justify-center w-full h-full text-gray-300 text-4xl">📷</div>
                    <?php endif; ?>
                </div>

                <!-- স্টক ব্যাজ -->
                <span class="absolute top-2 left-2 <?= $stockClass ?> text-xs font-semibold px-2 py-0.5 rounded-full">
                    <?= $stockLabel ?>
                </span>

                <!-- ইমেজ ডট ইন্ডিকেটর -->
                <?php if (count($imgs) > 1): ?>
                <div class="img-dots absolute bottom-2 left-0 right-0" id="dots-<?= $wid ?>">
                    <?php foreach ($imgs as $i => $_): ?>
                    <div class="img-dot <?= $i === 0 ? 'active' : '' ?>"></div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- তথ্য ও বাটন -->
            <div class="p-4">
                <div class="flex justify-between items-start mb-1">
                    <h2 class="watch-name text-base font-bold text-gray-800 leading-snug">
                        <?= htmlspecialchars($watch['name'], ENT_QUOTES, 'UTF-8') ?>
                    </h2>
                    <span class="text-xs text-gray-400 ml-2 shrink-0">কেনা: ৳<?= number_format((float)$watch['buying_price']) ?></span>
                </div>

                <p class="text-xs text-gray-500 mb-0.5">
                    মডেল: <span class="watch-model font-semibold text-gray-600"><?= htmlspecialchars($watch['model'], ENT_QUOTES, 'UTF-8') ?></span>
                </p>

                <?php if (!empty($watch['brand'])): ?>
                <p class="text-xs text-gray-400 mb-3">
                    ব্র্যান্ড: <span class="watch-brand font-semibold text-gray-500"><?= htmlspecialchars($watch['brand'], ENT_QUOTES, 'UTF-8') ?></span>
                </p>
                <?php else: ?>
                <div class="mb-3"></div>
                <?php endif; ?>

                <!-- কপি করার লুকানো টেক্সট -->
                <textarea id="short_info_<?= $wid ?>" class="hidden">⌚ Product: <?= htmlspecialchars($watch['name'], ENT_QUOTES, 'UTF-8') ?>
🔖 Model: <?= htmlspecialchars($watch['model'], ENT_QUOTES, 'UTF-8') ?>
💰 Price: <?= number_format((float)$watch['selling_price']) ?> Tk</textarea>

                <textarea id="full_info_<?= $wid ?>" class="hidden">⌚ Product: <?= htmlspecialchars($watch['name'], ENT_QUOTES, 'UTF-8') ?>
🔖 Model: <?= htmlspecialchars($watch['model'], ENT_QUOTES, 'UTF-8') ?><?= !empty($watch['brand']) ? "\n🏷 Brand: " . htmlspecialchars($watch['brand'], ENT_QUOTES, 'UTF-8') : '' ?>
💰 Price: <?= number_format((float)$watch['selling_price']) ?> Tk

📋 Details:
<?= htmlspecialchars($watch['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>

                <!-- বাটন সেকশন -->
                <div class="space-y-2">

                    <?php if (!empty($urlArr)): ?>
                    <button onclick="downloadAllImages('<?= htmlspecialchars($urlStr, ENT_QUOTES, 'UTF-8') ?>', '<?= htmlspecialchars($watch['name'], ENT_QUOTES, 'UTF-8') ?>')"
                        class="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium px-4 py-2 rounded-lg transition flex justify-center items-center gap-2">
                        📥 সব ছবি ডাউনলোড (<?= count($urlArr) ?> টি)
                    </button>
                    <?php endif; ?>

                    <div class="flex items-center justify-between bg-blue-50 px-3 py-2 rounded-lg border border-blue-100">
                        <div>
                            <span class="block text-xs text-blue-500 font-semibold uppercase tracking-wide">বিক্রির দাম</span>
                            <span class="text-lg font-bold text-blue-700">৳<?= number_format((float)$watch['selling_price']) ?></span>
                        </div>
                        <button onclick="copyText('short_info_<?= $wid ?>', 'শর্ট ইনফো')"
                            class="bg-blue-600 hover:bg-blue-700 text-white text-sm px-4 py-1.5 rounded-lg transition">
                            Copy Price
                        </button>
                    </div>

                    <button onclick="copyText('full_info_<?= $wid ?>', 'সম্পূর্ণ তথ্য')"
                        class="w-full bg-gray-800 hover:bg-gray-900 text-white text-sm font-medium px-4 py-2 rounded-lg transition">
                        📝 Copy Full Details
                    </button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>

        <?php if (empty($watches)): ?>
        <div class="col-span-full text-center py-14 bg-white rounded-xl border border-gray-200">
            <p class="text-gray-400 text-lg">এখনো কোনো ঘড়ি যোগ করা হয়নি।</p>
            <a href="admin/login.php" class="text-blue-500 text-sm mt-2 inline-block">Admin Panel →</a>
        </div>
        <?php endif; ?>

        <div id="noResultMessage" class="hidden col-span-full text-center py-14 bg-white rounded-xl border border-gray-200">
            <p class="text-gray-400 text-lg">এই নামের কোনো ঘড়ি পাওয়া যায়নি। ❌</p>
        </div>
    </div>
</div>

<script src="assets/js/script.js"></script>
<script>
// ব্র্যান্ড ফিল্টার
let activeBrand = '';
function filterByBrand(brand) {
    activeBrand = brand.toLowerCase();
    document.querySelectorAll('.brand-btn').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('onclick').includes("'" + brand + "'") || (brand === '' && btn.getAttribute('onclick').includes("''")));
        if (brand === '' && btn.textContent.trim() === 'সব') { btn.classList.add('active'); btn.classList.add('bg-gray-800'); btn.classList.add('text-white'); }
        else btn.classList.remove('bg-gray-800', 'text-white');
    });
    filterWatches();
}

// Override filterWatches to also apply brand filter
const _filterWatches = filterWatches;
window.filterWatches = function() {
    const input = document.getElementById('searchInput').value.toLowerCase();
    const cards = document.getElementsByClassName('watch-card');
    let hasResult = false;
    for (const card of cards) {
        const name  = (card.querySelector('.watch-name')?.innerText  || '').toLowerCase();
        const model = (card.querySelector('.watch-model')?.innerText || '').toLowerCase();
        const brand = (card.querySelector('.watch-brand')?.innerText || '').toLowerCase();
        const cardBrand = card.dataset.brand || '';
        const matchSearch = !input || name.includes(input) || model.includes(input) || brand.includes(input);
        const matchBrand  = !activeBrand || cardBrand === activeBrand;
        const show = matchSearch && matchBrand;
        card.style.display = show ? '' : 'none';
        if (show) hasResult = true;
    }
    const noResult = document.getElementById('noResultMessage');
    if (noResult) noResult.style.display = (hasResult || (!input && !activeBrand)) ? 'none' : 'block';
}

// ইমেজ ডট ইনিশিয়ালাইজ করা
document.querySelectorAll('[id^="slider-"]').forEach(slider => {
    const id = slider.id.replace('slider-', '');
    initSlider(id);
});

// Brand button active styles
document.querySelectorAll('.brand-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.brand-btn').forEach(b => {
            b.classList.remove('bg-gray-800', 'text-white');
            b.classList.add('bg-white', 'text-gray-600');
        });
        this.classList.add('bg-gray-800', 'text-white');
        this.classList.remove('bg-white', 'text-gray-600');
    });
});
</script>
</body>
</html>
