<?php
// includes/auth.php — সমস্ত অ্যাডমিন পেজে include করতে হবে

function require_admin_login() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        header("Location: " . (strpos($_SERVER['PHP_SELF'], '/admin/') !== false ? 'login.php' : 'admin/login.php'));
        exit;
    }
}

// CSRF টোকেন জেনারেট করা
function generate_csrf_token() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// CSRF টোকেন যাচাই করা
function verify_csrf_token($token) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        die("Invalid request. Please go back and try again.");
    }
}

// ছবি আপলোড — একটিমাত্র রিইউজেবল ফাংশন
function upload_images(array $files, PDO $pdo, int $watch_id): array {
    $uploadDir = __DIR__ . '/../assets/uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $allowedMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $maxSize      = 5 * 1024 * 1024; // 5MB
    $uploaded     = [];
    $errors       = [];

    $count = count($files['name']);
    for ($i = 0; $i < $count; $i++) {
        if ($files['error'][$i] !== UPLOAD_ERR_OK || empty($files['tmp_name'][$i])) {
            continue;
        }

        // ১. সাইজ চেক
        if ($files['size'][$i] > $maxSize) {
            $errors[] = $files['name'][$i] . " ফাইলটি 5MB এর বেশি।";
            continue;
        }

        // ২. MIME টাইপ চেক (extension নয়, আসল কন্টেন্ট)
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime  = $finfo->file($files['tmp_name'][$i]);
        if (!in_array($mime, $allowedMimes, true)) {
            $errors[] = $files['name'][$i] . " — শুধু JPG, PNG, WEBP, GIF অনুমোদিত।";
            continue;
        }

        // ৩. ইউনিক ফাইলনেম
        $ext      = match($mime) {
            'image/jpeg' => 'jpg',
            'image/png'  => 'png',
            'image/webp' => 'webp',
            'image/gif'  => 'gif',
            default      => 'jpg'
        };
        $filename    = uniqid('watch_', true) . '.' . $ext;
        $uploadPath  = $uploadDir . $filename;
        $dbPath      = 'assets/uploads/' . $filename; // শুধু ফাইলনেম স্টোর

        if (move_uploaded_file($files['tmp_name'][$i], $uploadPath)) {
            $stmt = $pdo->prepare("INSERT INTO watch_images (watch_id, image_url, sort_order) VALUES (:wid, :url, :sort)");
            $stmt->execute([':wid' => $watch_id, ':url' => $dbPath, ':sort' => $i]);
            $uploaded[] = $dbPath;
        }
    }

    return ['uploaded' => $uploaded, 'errors' => $errors];
}

// ফ্ল্যাশ মেসেজ সেট করা
function set_flash(string $type, string $message) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

// ফ্ল্যাশ মেসেজ পড়া এবং ডিলিট করা
function get_flash(): array {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $flash = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flash;
}
